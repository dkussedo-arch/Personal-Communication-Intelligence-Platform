'use client'

import { useState } from 'react'
import Link from 'next/link'
import { InputPanel, GenerationConfig } from '@/components/input-panel'
import { GenerationPanel } from '@/components/generation-panel'
import { AnalysisPanel } from '@/components/analysis-panel'
import { Brain, LogOut } from 'lucide-react'

export default function AppPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [currentConfig, setCurrentConfig] = useState<GenerationConfig | undefined>()
  const [hasGenerated, setHasGenerated] = useState(false)

  const handleGenerate = (config: GenerationConfig) => {
    setCurrentConfig(config)
    setIsLoading(true)
    setHasGenerated(true)

    // Simulate generation delay
    setTimeout(() => {
      setIsLoading(false)
    }, 7000)
  }

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/30 bg-background/80 backdrop-blur-sm">
        <div className="flex items-center justify-between px-6 py-4 md:px-8">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <Brain className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="font-semibold">PCI</span>
          </Link>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2">
              <div className="text-xs">
                <p className="font-medium text-foreground">Alex Johnson</p>
                <p className="text-muted-foreground">VP Strategy</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-accent/20 border border-accent/30" />
            </div>
            <Link href="/" className="p-2 hover:bg-card rounded-lg transition">
              <LogOut className="w-4 h-4 text-muted-foreground" />
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content - 3 Panel Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Input */}
        <div className="hidden md:flex w-80 flex-col border-r border-border/30">
          <InputPanel onGenerate={handleGenerate} isLoading={isLoading} />
        </div>

        {/* Center Panel - Generation */}
        <div className="flex-1 flex flex-col">
          <GenerationPanel isLoading={isLoading} config={currentConfig} generatedContent={undefined} />
        </div>

        {/* Right Panel - Analysis */}
        <div className="hidden lg:flex w-96 flex-col border-l border-border/30">
          <AnalysisPanel isLoading={isLoading} hasContent={hasGenerated} />
        </div>
      </div>

      {/* Mobile - Show panels one at a time */}
      {/* This is a simplified mobile view - in production, you'd want a more sophisticated mobile experience */}
    </div>
  )
}
