import mammoth from 'mammoth';

async function parseDocs() {
  try {
    // Parse Research Synthesis Report
    const research = await mammoth.extractRawText({ path: './data/PCI_Research_Synthesis_Report-3d1f24.docx' });
    console.log('=== RESEARCH SYNTHESIS REPORT ===\n', research.value.slice(0, 4000));
    
    // Parse AI Approach
    const aiApproach = await mammoth.extractRawText({ path: './data/PCI_AI_Product_Pattern_Selection-AI-Approach-76105f.docx' });
    console.log('\n\n=== AI PRODUCT PATTERN SELECTION ===\n', aiApproach.value.slice(0, 4000));
  } catch (error) {
    console.error('Error parsing:', error.message);
  }
}

parseDocs();
