'use client'

import { Loader, AlertCircle, AlertTriangle } from 'lucide-react'
import { GenerationConfig } from './input-panel'

interface GenerationPanelProps {
  isLoading: boolean
  config?: GenerationConfig
  generatedContent?: string
}

const GENERATION_STEPS = [
  'Retrieving corpus...',
  'Checking for position evolution...',
  'Assembling argument structure...',
  'Calibrating for audience...',
  'Groundedness verification...',
  'Constraint enforcement...',
  'Finalisation...',
]

const SAMPLE_DRAFT = `Board Strategic Position: Digital Transformation Roadmap

**Executive Summary**

Our three-year digital transformation initiative has successfully positioned us as the market leader in adoption velocity. This memo synthesizes our current strategic position and outlines critical decision points for Board approval.

**Key Findings & Strategic Position**

As established in Q3 2025 strategy review, our core thesis remains: *competitive advantage accrues to organizations that simultaneously optimize for speed AND integration depth*. This principle has guided our architecture decisions across three pillars:

1. **Platform Consolidation** (Grounded in market analysis, Sept 2025)
   - Status: 73% of legacy systems migrated
   - Credibility indicator: Supported by Gartner research on modernization ROI

2. **Skill Development** (Your established position from June 2025 investor update)
   - We're building internal capability, not outsourcing critical competencies
   - Evidence: 340 employees completed certification; 18 net hires in engineering

3. **Customer Impact** (Aligned with your client communication from Aug 2025)
   - Response time reduced 42% (source: internal telemetry)
   - Enterprise satisfaction score: 8.7/10 (vs. 7.2 industry average)

**Constraints & Deliberate Positioning**

Per your established guardrails, this memo does NOT address:
- Acquisition strategy (as discussed, this remains confidential)
- Specific vendor partnerships (to preserve negotiation position)
- Technical architecture details (to maintain competitive advantage)

**Recommended Next Steps**

The Board should consider approval of Phase 2 funding (+$8M over 18 months) to accelerate customer migration and expand the data analytics platform.

---

*Draft fidelity score: 94% | All claims source-attributed | 3 constraints enforced*`;

export function GenerationPanel({ isLoading, config, generatedContent }: GenerationPanelProps) {
  const [currentStep, setCurrentStep] = React.useState(0)

  React.useEffect(() => {
    if (!isLoading) {
      setCurrentStep(0)
      return
    }

    const timer = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % GENERATION_STEPS.length)
    }, 1200)

    return () => clearInterval(timer)
  }, [isLoading])

  if (!config && !generatedContent) {
    return (
      <div className="flex flex-col h-full bg-background border-r border-border/30 items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-lg bg-card border border-border/30 flex items-center justify-center mb-4">
          <svg className="w-8 h-8 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h3 className="text-sm font-semibold mb-2">No draft yet</h3>
        <p className="text-xs text-muted-foreground">Configure your parameters and click "Generate Draft" to get started</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-background border-r border-border/30 overflow-hidden">
      {/* Header */}
      <div className="sticky top-0 bg-background border-b border-border/30 p-6 z-10">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h2 className="text-lg font-semibold">{config?.documentType}</h2>
            <p className="text-xs text-muted-foreground">For: {config?.audience}</p>
          </div>
          {isLoading && <Loader className="w-5 h-5 text-accent animate-spin" />}
        </div>
      </div>

      {/* Generation Status or Content */}
      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="p-6 space-y-6">
            {/* Status Messages */}
            <div className="space-y-3">
              {GENERATION_STEPS.map((step, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center">
                    {idx < currentStep ? (
                      <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center">
                        <div className="w-2 h-2 bg-accent rounded-full" />
                      </div>
                    ) : idx === currentStep ? (
                      <Loader className="w-4 h-4 text-accent animate-spin" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border border-border" />
                    )}
                  </div>
                  <p className={`text-sm ${idx <= currentStep ? 'text-foreground' : 'text-muted-foreground'}`}>
                    {step}
                  </p>
                </div>
              ))}
            </div>

            {/* Progress Bar */}
            <div className="w-full h-1 bg-card rounded-full overflow-hidden">
              <div
                className="h-full bg-accent transition-all duration-300"
                style={{ width: `${((currentStep + 1) / GENERATION_STEPS.length) * 100}%` }}
              />
            </div>

            <p className="text-xs text-muted-foreground italic">This usually takes 3-8 seconds</p>
          </div>
        ) : (
          <div className="p-6 space-y-6">
            {/* Draft Content */}
            <div className="prose prose-invert max-w-none text-sm">
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                {generatedContent || SAMPLE_DRAFT.split('\n\n').map((paragraph, idx) => (
                  <div key={idx} className="text-sm">
                    {paragraph.startsWith('**') ? (
                      <p className="font-semibold text-foreground mb-2">{paragraph.replace(/\*\*/g, '')}</p>
                    ) : paragraph.startsWith('-') || paragraph.startsWith('1.') || paragraph.startsWith('2.') || paragraph.startsWith('3.') ? (
                      <ul className="space-y-1 ml-4">
                        {paragraph.split('\n').map((line, i) => (
                          <li key={i} className="list-disc text-muted-foreground">{line.replace(/^[-0-9.]\s/, '')}</li>
                        ))}
                      </ul>
                    ) : (
                      <p>{paragraph}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Stats */}
            <div className="pt-4 border-t border-border/30 space-y-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <AlertCircle className="w-3 h-3 text-accent" />
                Fidelity Score: <span className="font-semibold text-accent">94%</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <AlertTriangle className="w-3 h-3 text-amber-500" />
                Constraints enforced: <span className="font-semibold">3</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      {!isLoading && (
        <div className="sticky bottom-0 p-6 border-t border-border/30 bg-background space-y-3">
          <button className="w-full px-4 py-2 rounded-lg bg-accent text-accent-foreground font-medium hover:bg-accent/90 transition text-sm">
            Accept & Publish
          </button>
          <button className="w-full px-4 py-2 rounded-lg border border-border text-foreground font-medium hover:bg-card transition text-sm">
            Edit Draft
          </button>
        </div>
      )}
    </div>
  )
}

import React from 'react'
