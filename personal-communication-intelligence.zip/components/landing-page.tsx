'use client'

import Link from 'next/link'
import { ArrowRight, CheckCircle2, Zap, Brain, Shield, Lock, TrendingUp } from 'lucide-react'

export function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-sm">
        <nav className="flex items-center justify-between px-6 py-4 md:px-12">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
              <Brain className="w-5 h-5 text-accent-foreground" />
            </div>
            <span className="font-semibold text-lg">PCI</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition">Features</a>
            <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition">How It Works</a>
            <a href="#testimonials" className="text-sm text-muted-foreground hover:text-foreground transition">Testimonials</a>
          </div>
          <Link href="/app" className="px-4 py-2 rounded-lg bg-accent text-accent-foreground text-sm font-medium hover:bg-accent/90 transition">
            Try It Free
          </Link>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative px-6 py-20 md:py-32 md:px-12 text-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-transparent" />
        <div className="relative max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-border bg-card/50 mb-6">
            <Zap className="w-4 h-4 text-accent" />
            <span className="text-xs font-medium text-muted-foreground">Powered by Communication Intelligence</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
            Your expertise.<br />
            <span className="text-accent">Your voice.</span> At scale.
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Generate authentic, expertise-grounded content that preserves your reasoning, maintains your position, and protects your credibility.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/app" className="px-8 py-3 rounded-lg bg-accent text-accent-foreground font-medium hover:bg-accent/90 transition inline-flex items-center justify-center gap-2">
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </Link>
            <button className="px-8 py-3 rounded-lg border border-border hover:bg-card transition inline-flex items-center justify-center gap-2 font-medium">
              Watch Demo
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 md:gap-8 text-center mt-12 pt-12 border-t border-border/30">
            <div>
              <div className="text-2xl md:text-3xl font-bold text-accent mb-2">83%</div>
              <p className="text-xs md:text-sm text-muted-foreground">Rate cross-session memory<br />as critical</p>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-accent mb-2">77%</div>
              <p className="text-xs md:text-sm text-muted-foreground">Currently edit AI output<br />heavily</p>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-accent mb-2">41%</div>
              <p className="text-xs md:text-sm text-muted-foreground">Choose PCI for source<br />attribution</p>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="px-6 py-16 md:py-24 md:px-12 border-t border-border/30">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">The Gap Between AI and Expertise</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Generic AI tools start from zero, forcing you to inject context, correct reasoning errors, and risk your credibility. PCI starts from your established expertise, protected positions, and authentic communication patterns.
          </p>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
              <h3 className="font-semibold text-destructive mb-2">The Problem</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li className="flex gap-2"><span className="text-destructive">✕</span> Wrong reasoning structure</li>
                <li className="flex gap-2"><span className="text-destructive">✕</span> Missing domain expertise</li>
                <li className="flex gap-2"><span className="text-destructive">✕</span> No position consistency</li>
                <li className="flex gap-2"><span className="text-destructive">✕</span> Credibility risk</li>
              </ul>
            </div>
            <div className="p-4 rounded-lg border border-accent/20 bg-accent/5">
              <h3 className="font-semibold text-accent mb-2">PCI Solution</h3>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li className="flex gap-2"><CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" /> Preserves your reasoning</li>
                <li className="flex gap-2"><CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" /> Grounded in your corpus</li>
                <li className="flex gap-2"><CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" /> Maintains position memory</li>
                <li className="flex gap-2"><CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" /> Source-attributed claims</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="px-6 py-16 md:py-24 md:px-12 bg-card/30 border-t border-border/30">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Three Pillars of Communication Intelligence</h2>
            <p className="text-lg text-muted-foreground">The features that differentiate PCI from every writing tool</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <div className="p-6 rounded-lg border border-border bg-background hover:border-accent/50 transition">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Persistent Position Memory</h3>
              <p className="text-sm text-muted-foreground mb-4">
                PCI learns and remembers your established strategic positions, expertise, and reasoning patterns—never starting from zero.
              </p>
              <ul className="text-xs text-muted-foreground space-y-2">
                <li className="flex gap-2"><span className="text-accent">•</span> Your positions auto-evolve</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Cross-session consistency</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Audience-specific reasoning</li>
              </ul>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-lg border border-border bg-background hover:border-accent/50 transition">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Source-Attributed Generation</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Every claim is traceable to your corpus. Know exactly where each argument comes from and maintain credibility.
              </p>
              <ul className="text-xs text-muted-foreground space-y-2">
                <li className="flex gap-2"><span className="text-accent">•</span> Full claim attribution</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Groundedness verification</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Confidence scoring</li>
              </ul>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-lg border border-border bg-background hover:border-accent/50 transition">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                <Lock className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Constraint Architecture</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Define what you deliberately choose NOT to say. PCI respects your boundaries and competitive positioning.
              </p>
              <ul className="text-xs text-muted-foreground space-y-2">
                <li className="flex gap-2"><span className="text-accent">•</span> Define communication rules</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Protect sensitive positions</li>
                <li className="flex gap-2"><span className="text-accent">•</span> Enforce guardrails</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="px-6 py-16 md:py-24 md:px-12 border-t border-border/30">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">How It Works</h2>

          <div className="space-y-8">
            {/* Step 1 */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-accent text-accent-foreground font-semibold">1</div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Connect Your Corpus</h3>
                <p className="text-muted-foreground">Upload your documents, reports, and communications. PCI builds a model of your expertise, positions, and voice.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-accent text-accent-foreground font-semibold">2</div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Define Your Position</h3>
                <p className="text-muted-foreground">Specify your established thesis, audience, and any constraints. PCI starts from your known position, not a blank slate.</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-accent text-accent-foreground font-semibold">3</div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Generate & Review</h3>
                <p className="text-muted-foreground">Get a fully drafted communication with source attribution and groundedness scoring. Review, edit, and publish with confidence.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="px-6 py-16 md:py-24 md:px-12 bg-card/30 border-t border-border/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Trusted by Knowledge Leaders</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Testimonial 1 */}
            <div className="p-6 rounded-lg border border-border bg-background">
              <div className="flex items-center gap-2 mb-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="text-accent text-sm">★</div>
                ))}
              </div>
              <p className="text-muted-foreground mb-4 leading-relaxed italic">
                &quot;PCI starts from what I&apos;ve already established, not from zero. That changes everything about how I approach AI-assisted writing.&quot;
              </p>
              <div>
                <p className="font-semibold text-sm">Margaret K.</p>
                <p className="text-xs text-muted-foreground">Chief Strategy Officer, Financial Services</p>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="p-6 rounded-lg border border-border bg-background">
              <div className="flex items-center gap-2 mb-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="text-accent text-sm">★</div>
                ))}
              </div>
              <p className="text-muted-foreground mb-4 leading-relaxed italic">
                &quot;Knowing exactly where each claim comes from—that&apos;s the credibility insurance every executive needs when delegating to AI.&quot;
              </p>
              <div>
                <p className="font-semibold text-sm">Dr. James H.</p>
                <p className="text-xs text-muted-foreground">VP Policy & Research</p>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="p-6 rounded-lg border border-border bg-background">
              <div className="flex items-center gap-2 mb-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="text-accent text-sm">★</div>
                ))}
              </div>
              <p className="text-muted-foreground mb-4 leading-relaxed italic">
                &quot;Finally, a tool that lets me set guardrails—things I deliberately don&apos;t want AI to generate. That&apos;s mature AI design.&quot;
              </p>
              <div>
                <p className="font-semibold text-sm">Sophia R.</p>
                <p className="text-xs text-muted-foreground">Senior Consultant, Strategy & Ops</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="px-6 py-16 md:py-24 md:px-12 border-t border-border/30 bg-gradient-to-br from-accent/10 via-background to-background">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Generate with Credibility?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start generating expertise-grounded content today. No credit card required.
          </p>
          <Link href="/app" className="inline-flex px-8 py-4 rounded-lg bg-accent text-accent-foreground font-semibold hover:bg-accent/90 transition text-lg">
            Get Started Free
            <ArrowRight className="w-5 h-5 ml-2" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 md:px-12 border-t border-border/30 bg-card/30">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>&copy; 2026 Personal Communication Intelligence. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-foreground transition">Privacy</a>
            <a href="#" className="hover:text-foreground transition">Terms</a>
            <a href="#" className="hover:text-foreground transition">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
