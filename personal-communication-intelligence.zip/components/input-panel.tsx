'use client'

import { FileUp, BookOpen, Plus } from 'lucide-react'
import { useState } from 'react'

interface InputPanelProps {
  onGenerate: (config: GenerationConfig) => void
  isLoading?: boolean
}

export interface GenerationConfig {
  documentType: string
  audience: string
  establishedPosition: string
  keyTopic: string
}

const DOCUMENT_TYPES = [
  'Board Memo',
  'Investor Update',
  'Policy Brief',
  'Research Synthesis',
  'Executive Summary',
  'Strategy Proposal',
  'Client Presentation',
  'Internal Communication',
]

const AUDIENCES = [
  'Board of Directors',
  'Executive Team',
  'Investors',
  'Policy Makers',
  'Technical Team',
  'Client Stakeholders',
  'Public Audience',
  'Internal Team',
]

export function InputPanel({ onGenerate, isLoading }: InputPanelProps) {
  const [documentType, setDocumentType] = useState(DOCUMENT_TYPES[0])
  const [audience, setAudience] = useState(AUDIENCES[0])
  const [establishedPosition, setEstablishedPosition] = useState('')
  const [keyTopic, setKeyTopic] = useState('')

  const handleGenerate = () => {
    if (establishedPosition.trim() && keyTopic.trim()) {
      onGenerate({
        documentType,
        audience,
        establishedPosition,
        keyTopic,
      })
    }
  }

  const corpusStats = {
    documentCount: 124,
    diversity: 'High',
    lastUpdated: '2 days ago',
  }

  return (
    <div className="flex flex-col h-full bg-background border-r border-border/30 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-background border-b border-border/30 p-6 z-10">
        <h2 className="text-lg font-semibold mb-1">New Draft</h2>
        <p className="text-xs text-muted-foreground">Configure your generation parameters</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Corpus Badge */}
        <div className="p-3 rounded-lg border border-border bg-card/50">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="w-4 h-4 text-accent" />
            <span className="text-xs font-semibold text-muted-foreground">Your Corpus</span>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-sm font-semibold text-foreground">{corpusStats.documentCount}</div>
              <div className="text-xs text-muted-foreground">Documents</div>
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground">{corpusStats.diversity}</div>
              <div className="text-xs text-muted-foreground">Diversity</div>
            </div>
            <div>
              <div className="text-sm font-semibold text-foreground">{corpusStats.lastUpdated}</div>
              <div className="text-xs text-muted-foreground">Freshness</div>
            </div>
          </div>
        </div>

        {/* Document Type */}
        <div>
          <label className="block text-xs font-semibold text-muted-foreground mb-2">Document Type</label>
          <select
            value={documentType}
            onChange={(e) => setDocumentType(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/50"
          >
            {DOCUMENT_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* Audience */}
        <div>
          <label className="block text-xs font-semibold text-muted-foreground mb-2">Target Audience</label>
          <select
            value={audience}
            onChange={(e) => setAudience(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/50"
          >
            {AUDIENCES.map((aud) => (
              <option key={aud} value={aud}>
                {aud}
              </option>
            ))}
          </select>
        </div>

        {/* Established Position */}
        <div>
          <label className="block text-xs font-semibold text-muted-foreground mb-2">Your Established Position</label>
          <textarea
            value={establishedPosition}
            onChange={(e) => setEstablishedPosition(e.target.value)}
            placeholder="Enter your current thesis or key stance. This anchors the generation to your known positions..."
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none h-24 placeholder-muted-foreground/50"
          />
          <p className="text-xs text-muted-foreground mt-2">
            PCI starts from your position, not from zero. This is the most important field.
          </p>
        </div>

        {/* Key Topic */}
        <div>
          <label className="block text-xs font-semibold text-muted-foreground mb-2">Key Topic or Prompt</label>
          <textarea
            value={keyTopic}
            onChange={(e) => setKeyTopic(e.target.value)}
            placeholder="What do you want to cover in this draft? Be specific about context, scope, or specific arguments..."
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none h-20 placeholder-muted-foreground/50"
          />
        </div>

        {/* Info Box */}
        <div className="p-3 rounded-lg bg-accent/5 border border-accent/20">
          <p className="text-xs text-muted-foreground leading-relaxed">
            💡 <strong>Tip:</strong> Your established position anchors all generation to your known expertise. The more specific your position, the more authentic the draft.
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="sticky bottom-0 p-6 border-t border-border/30 bg-background space-y-3">
        <button
          onClick={handleGenerate}
          disabled={!establishedPosition.trim() || !keyTopic.trim() || isLoading}
          className="w-full px-4 py-3 rounded-lg bg-accent text-accent-foreground font-semibold hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed transition text-sm flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-accent-foreground border-t-transparent rounded-full animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Plus className="w-4 h-4" />
              Generate Draft
            </>
          )}
        </button>
        <button className="w-full px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-card transition">
          Upload Corpus
        </button>
      </div>
    </div>
  )
}
