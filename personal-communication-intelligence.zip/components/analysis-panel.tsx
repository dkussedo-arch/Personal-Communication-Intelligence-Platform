'use client'

import { CheckCircle2, AlertCircle, AlertTriangle, BookOpen, Settings2, Zap } from 'lucide-react'
import { useState } from 'react'

interface AnalysisPanelProps {
  isLoading?: boolean
  hasContent?: boolean
}

export function AnalysisPanel({ isLoading, hasContent }: AnalysisPanelProps) {
  const [activeTab, setActiveTab] = useState<'fidelity' | 'claims' | 'constraints'>('fidelity')

  if (!hasContent && !isLoading) {
    return (
      <div className="flex flex-col h-full bg-background overflow-hidden">
        <div className="flex items-center justify-center h-full p-6 text-center">
          <div>
            <div className="w-12 h-12 rounded-lg bg-card border border-border/30 flex items-center justify-center mx-auto mb-3">
              <Zap className="w-6 h-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-semibold mb-1">No analysis yet</h3>
            <p className="text-xs text-muted-foreground">Generate a draft to see voice fidelity analysis, source attribution, and constraint verification</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="sticky top-0 bg-background border-b border-border/30 p-6 z-10">
        <h3 className="text-sm font-semibold mb-4">Generation Analysis</h3>
        <div className="flex gap-2">
          {(['fidelity', 'claims', 'constraints'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`text-xs font-medium px-3 py-1 rounded transition ${
                activeTab === tab
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-card text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab === 'fidelity' && 'Voice'}
              {tab === 'claims' && 'Claims'}
              {tab === 'constraints' && 'Constraints'}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {activeTab === 'fidelity' && (
          <div className="space-y-4">
            {/* Fidelity Score */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold">Voice Fidelity Score</h4>
                <span className="text-lg font-bold text-accent">94%</span>
              </div>
              <div className="h-2 bg-card rounded-full overflow-hidden">
                <div className="h-full w-[94%] bg-accent rounded-full" />
              </div>
              <p className="text-xs text-muted-foreground">Your authentic communication patterns closely matched</p>
            </div>

            {/* Dimensions */}
            <div className="pt-4 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground">Fidelity Breakdown</p>

              {[
                { name: 'Argument Structure', score: 96 },
                { name: 'Vocabulary Match', score: 91 },
                { name: 'Opening Convention', score: 89 },
                { name: 'Evidence Preference', score: 94 },
              ].map((dim) => (
                <div key={dim.name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">{dim.name}</span>
                    <span className="text-xs font-semibold text-accent">{dim.score}%</span>
                  </div>
                  <div className="h-1.5 bg-card rounded-full overflow-hidden">
                    <div
                      className="h-full bg-accent rounded-full"
                      style={{ width: `${dim.score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-lg bg-accent/5 border border-accent/20">
              <p className="text-xs text-muted-foreground leading-relaxed">
                The generation closely mirrors your established communication style. Minor adjustments to opening phrasing could increase fidelity to 97%.
              </p>
            </div>
          </div>
        )}

        {activeTab === 'claims' && (
          <div className="space-y-4">
            <p className="text-xs font-semibold text-muted-foreground mb-4">Source Attribution & Groundedness</p>

            {/* Claims List */}
            <div className="space-y-3">
              {[
                {
                  claim: '73% of legacy systems migrated',
                  status: 'grounded',
                  source: 'Internal telemetry, Sept 2025',
                  confidence: 98,
                },
                {
                  claim: 'Competitive advantage accrues to organizations that optimize for speed AND integration',
                  status: 'inferred',
                  source: 'Your Q3 2025 strategy memo + Gartner research',
                  confidence: 87,
                },
                {
                  claim: 'Enterprise satisfaction 8.7/10 vs. 7.2 industry average',
                  status: 'grounded',
                  source: 'Client survey data, Aug 2025',
                  confidence: 94,
                },
                {
                  claim: 'Response time reduced 42%',
                  status: 'grounded',
                  source: 'Platform telemetry dashboard',
                  confidence: 99,
                },
              ].map((item, idx) => (
                <div key={idx} className="p-3 rounded-lg border border-border bg-card/50 space-y-2">
                  <div className="flex items-start gap-2">
                    {item.status === 'grounded' ? (
                      <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                    )}
                    <p className="text-xs font-medium leading-snug flex-1">{item.claim}</p>
                  </div>
                  <div className="text-xs text-muted-foreground ml-6">
                    <p className="mb-1">
                      <span className={item.status === 'grounded' ? 'text-accent' : 'text-amber-500'}>
                        {item.status === 'grounded' ? '✓ Fully grounded' : '⚠ Inferred'}
                      </span>
                    </p>
                    <p className="text-muted-foreground">{item.source}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <div className="h-1 w-16 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full ${item.confidence > 90 ? 'bg-accent' : 'bg-amber-500'}`}
                          style={{ width: `${item.confidence}%` }}
                        />
                      </div>
                      <span className="text-xs font-semibold">{item.confidence}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
              <div className="flex gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-500/90 leading-relaxed">
                  1 claim (Competitive advantage...) is inferred beyond your source material. Review on hover to see the inference details.
                </p>
              </div>
            </div>

            {/* Corpus Freshness */}
            <div className="p-3 rounded-lg border border-border bg-card/50 space-y-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs font-semibold text-muted-foreground">Corpus Freshness Alert</span>
              </div>
              <p className="text-xs text-muted-foreground">Last ingestion: 2 days ago. Recent strategy updates may not be reflected.</p>
              <button className="text-xs font-medium text-accent hover:text-accent/80 mt-2">Filter by date range →</button>
            </div>
          </div>
        )}

        {activeTab === 'constraints' && (
          <div className="space-y-4">
            <p className="text-xs font-semibold text-muted-foreground mb-4">Constraint Verification</p>

            {/* Constraints */}
            <div className="space-y-3">
              {[
                {
                  constraint: 'Acquisition strategy remains confidential',
                  status: 'enforced',
                },
                {
                  constraint: 'Vendor partnerships not disclosed',
                  status: 'enforced',
                },
                {
                  constraint: 'Technical architecture details proprietary',
                  status: 'enforced',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg border border-border bg-card/50 flex items-start gap-3"
                >
                  <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-xs font-medium">{item.constraint}</p>
                    <p className="text-xs text-muted-foreground mt-1">✓ Not mentioned in draft</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-lg bg-accent/5 border border-accent/20">
              <div className="flex gap-2">
                <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                <p className="text-xs text-accent/90">
                  All 3 constraints successfully enforced. No sensitive information leaked.
                </p>
              </div>
            </div>

            {/* Add Constraint */}
            <div className="pt-4 border-t border-border/30">
              <button className="text-xs font-medium text-accent hover:text-accent/80 flex items-center gap-1">
                <Settings2 className="w-3 h-3" />
                Teach PCI new constraints
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="sticky bottom-0 p-6 border-t border-border/30 bg-background">
        <button className="w-full px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-card transition">
          Learn More →
        </button>
      </div>
    </div>
  )
}
